package com.brightbank_c.complexForm.service;


import com.brightbank_c.complexForm.model.*;
import com.brightbank_c.complexForm.model.EmployeeProfileBody;
import com.brightbank_c.complexForm.model.InlineResponse200;
import com.brightbank_c.complexForm.model.InlineResponse2001;
import com.brightbank_c.complexForm.model.InlineResponse2002;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Object;
import org.springframework.util.MultiValueMap;
import feign.*;

public interface DefaultService {

  /**
   * Get All Departments
   * 
   * @return List&lt;InlineResponse2002&gt;
   */
  @RequestLine("GET /departments")
  @Headers({
    "Accept: application/json",  })
  List<InlineResponse2002> getDepartments();

  /**
   * Get All Roles
   * 
   * @return List&lt;InlineResponse200&gt;
   */
  @RequestLine("GET /roles")
  @Headers({
    "Accept: application/json",  })
  List<InlineResponse200> getRoles();

  /**
   * Submit Employee Profile
   * 
    * @param body  (required)
   * @return InlineResponse2001
   */
  @RequestLine("POST /employee/profile")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse2001 submitEmployeeProfile(EmployeeProfileBody body);

}
