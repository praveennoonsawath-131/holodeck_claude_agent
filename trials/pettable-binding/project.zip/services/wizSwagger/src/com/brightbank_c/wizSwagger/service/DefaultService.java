package com.brightbank_c.wizSwagger.service;


import com.brightbank_c.wizSwagger.model.*;
import com.brightbank_c.wizSwagger.model.VirtualCardApplication;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Object;
import org.springframework.util.MultiValueMap;
import feign.*;

public interface DefaultService {

  /**
   * Submit full virtual card application
   * 
    * @param body  (required)
   */
  @RequestLine("POST /apply-virtual-card")
  @Headers({
    "Content-Type: application/json",
    "Accept: ",  })
  void postApplyVirtualCard(VirtualCardApplication body);

}
