package com.brightbank_c.weavr.service;


import com.brightbank_c.weavr.model.*;
import com.brightbank_c.weavr.model.Error;
import com.brightbank_c.weavr.model.InlineResponse20014;
import com.brightbank_c.weavr.model.InlineResponse20016;
import com.brightbank_c.weavr.model.InlineResponse400;
import com.brightbank_c.weavr.model.InlineResponse403;
import com.brightbank_c.weavr.model.InlineResponse40920;
import com.brightbank_c.weavr.model.InlineResponse40947;
import com.brightbank_c.weavr.model.InlineResponse40948;
import com.brightbank_c.weavr.model.InlineResponse40952;
import com.brightbank_c.weavr.model.SCAVerifyRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Object;
import org.springframework.util.MultiValueMap;
import feign.*;

public interface AdditionalFactorsService {

  /**
   * Get user authentication factors
   * Retrieves the list of authentication factors that can be used to verify the logged-in user.
   * @return InlineResponse20014
   */
  @RequestLine("GET /authentication_factors")
  @Headers({
    "Accept: application/json",  })
  InlineResponse20014 authFactorsGet();

  /**
   * Enrol a user device for authentication using one-time passwords
   * This is the first step in enrolling the logged-in user&#x27;s mobile device, where a one-time password is sent to the device.  _Note that on the Sandbox Environment, text messages are not sent and the one-time-password is always \\\&quot;123456\\\&quot;._ 
    * @param channel The unique identifier for the channel. (required)
   */
  @RequestLine("POST /authentication_factors/otp/{channel}")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void enrolDeviceUsingOtpStepOne(@Param("channel") Object channel);

  /**
   * Verify enrolment of a user device for authentication using one-time passwords
   * The second step in enrolling the logged-in user (root or authorised user) to use one-time-passwords to enable verification of transactions.  _Note that on the Sandbox Environment, text messages are not sent and the &#x60;verificationCode&#x60; is always set to \\\&quot;123456\\\&quot;._ 
    * @param channel The unique identifier for the channel. (required)
    * @param body  (optional)
   */
  @RequestLine("POST /authentication_factors/otp/{channel}/verify")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void enrolDeviceUsingOtpStepTwo(@Param("channel") Object channel, SCAVerifyRequest body);

  /**
   * Enrol a user device for authentication using push notifications
   * This is the first step in enrolling the logged-in user&#x27;s mobile device, where a push notification is sent to the device. 
    * @param channel  (required)
   * @return InlineResponse20016
   */
  @RequestLine("POST /authentication_factors/push/{channel}")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse20016 enrolDeviceUsingPush(@Param("channel") Object channel);

  /**
   * Unlink a user device for authentication using push notifications
   * Unlink a user device for authentication using push notifications
    * @param channel  (required)
   */
  @RequestLine("DELETE /authentication_factors/push/{channel}")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void unlinkDeviceUsingPush(@Param("channel") Object channel);

}
