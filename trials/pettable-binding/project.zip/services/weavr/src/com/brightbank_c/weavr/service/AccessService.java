package com.brightbank_c.weavr.service;


import com.brightbank_c.weavr.model.*;
import com.brightbank_c.weavr.model.AccessTokenRequest;
import com.brightbank_c.weavr.model.Error;
import com.brightbank_c.weavr.model.InlineResponse20012;
import com.brightbank_c.weavr.model.InlineResponse20017;
import com.brightbank_c.weavr.model.InlineResponse20020;
import com.brightbank_c.weavr.model.InlineResponse2008;
import com.brightbank_c.weavr.model.InlineResponse400;
import com.brightbank_c.weavr.model.InlineResponse40926;
import com.brightbank_c.weavr.model.InlineResponse40929;
import com.brightbank_c.weavr.model.InlineResponse40933;
import com.brightbank_c.weavr.model.InlineResponse40936;
import com.brightbank_c.weavr.model.InlineResponse40939;
import com.brightbank_c.weavr.model.LoginWithPasswordRequest;
import com.brightbank_c.weavr.model.SCAVerifyRequest;
import com.brightbank_c.weavr.model.UserIdentity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Object;
import org.springframework.util.MultiValueMap;
import feign.*;

public interface AccessService {

  /**
   * Login with password
   * Authenticate a user with the &#x60;email&#x60; and &#x60;password&#x60; that they provided when registering.  Given that the user credentials are correct, this returns a &#x60;token&#x60; that can then be used to authorise other secured operations. In case the password is expired, a temporary &#x60;token&#x60; is returned, which can be used solely for updating the password.  The token returned is valid for 5 minutes from last activity. 
    * @param body  (optional)
   * @return InlineResponse20012
   */
  @RequestLine("POST /login_with_password")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse20012 loginWithPassword(LoginWithPasswordRequest body);

  /**
   * Logout
   * Logs out the user and terminates the session identified by the &#x60;auth_token&#x60; in the Authorization Header.
   * @return InlineResponse2008
   */
  @RequestLine("POST /logout")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse2008 logout();

  /**
   * Acquire a new access token
   * This API endpoint accepts a POST request with an auth_token parameter and returns an access_token that grants authorized access to additional resources within the API, with a different expiration time and unique signature. 
    * @param body  (optional)
   * @return InlineResponse20020
   */
  @RequestLine("POST /access_token")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse20020 requestAccessToken(AccessTokenRequest body);

  /**
   * Issue a one-time password that can be used to step-up a token
   * Initiates the step-up token process by sending an SMS with an one-time-password to a device belonging to the logged-in user that was previously enrolled through &#x60;/authentication_factors/otp/{channel}&#x60; endpoint.  This process is required for endpoints that require a step-up token to complete the call.  _Note that on the Sandbox Environment, text messages are not sent and the one-time-password is always \\\&quot;123456\\\&quot;._ 
    * @param channel The unique identifier for the channel. (required)
   */
  @RequestLine("POST /stepup/challenges/otp/{channel}")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void stepupSCAChallenge(@Param("channel") Object channel);

  /**
   * Issue a push notification that can be used to step-up a token
   * Initiates the step-up token process by submitting a push notification to a device belonging to the logged-in user that was previously enrolled through the &#x60;/authentication_factors/push/{channel}&#x60; endpoint.  You should only start this process if the token step-up isn&#x27;t already in flight. 
    * @param channel  (required)
   * @return InlineResponse20017
   */
  @RequestLine("POST /stepup/challenges/push/{channel}")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse20017 stepupSCAChallengePush(@Param("channel") Object channel);

  /**
   * Verify a step-up token using a one-time password
   * Completes the verification process for a step up token.  _Note that on the Sandbox Environment, text messages are not sent and the &#x60;verificationCode&#x60; is always \\\&quot;123456\\\&quot;._ 
    * @param channel The unique identifier for the channel. (required)
    * @param body  (optional)
   */
  @RequestLine("POST /stepup/challenges/otp/{channel}/verify")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void stepupSCAVerify(@Param("channel") Object channel, SCAVerifyRequest body);

  /**
   * Get user identities
   * Retrieves a list of identities available to the holder of the token.
   * @return List&lt;UserIdentity&gt;
   */
  @RequestLine("GET /identities")
  @Headers({
    "Accept: application/json",  })
  List<UserIdentity> userIdentities();

}
