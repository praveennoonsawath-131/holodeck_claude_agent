package com.brightbank_c.weavr.service;


import com.brightbank_c.weavr.model.*;
import com.brightbank_c.weavr.model.EmailSendBody;
import com.brightbank_c.weavr.model.EmailVerifyBody;
import com.brightbank_c.weavr.model.Error;
import com.brightbank_c.weavr.model.InlineResponse20015;
import com.brightbank_c.weavr.model.InlineResponse20019;
import com.brightbank_c.weavr.model.InlineResponse400;
import com.brightbank_c.weavr.model.InlineResponse40911;
import com.brightbank_c.weavr.model.InlineResponse40913;
import com.brightbank_c.weavr.model.InlineResponse40921;
import com.brightbank_c.weavr.model.InlineResponse40922;
import com.brightbank_c.weavr.model.InlineResponse40935;
import com.brightbank_c.weavr.model.InlineResponse40938;
import com.brightbank_c.weavr.model.InlineResponse40944;
import com.brightbank_c.weavr.model.InlineResponse40954;
import com.brightbank_c.weavr.model.TokenResponse;
import com.brightbank_c.weavr.model.User;
import com.brightbank_c.weavr.model.UserCreateRequest;
import com.brightbank_c.weavr.model.UserInviteConsumeRequest;
import com.brightbank_c.weavr.model.UserInviteValidateRequest;
import com.brightbank_c.weavr.model.UserPatchRequest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Object;
import org.springframework.util.MultiValueMap;
import feign.*;

public interface AuthorisedUsersService {

  /**
   * Send an email verification code to the authorised user
   * The first step in verifying an authorised user&#x27;s email. The authorised user whose email address is to be verified is sent an email containing a randomly generated code.  This code must then be provided in the _authorisedUserEmailVerify_ operation to verify the authorised user&#x27;s email address.  _Note that on the Sandbox Environment, the &#x60;verificationCode&#x60; is always set to \\\&quot;123456\\\&quot;._ 
    * @param body  (required)
   */
  @RequestLine("POST /users/verification/email/send")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void authorisedUserEmailVerificationCodeSend(EmailSendBody body);

  /**
   * Verify email of the authorised user
   * The second step in verifying the authorised user&#x27;s email. The randomly generated code sent to the authorised user via email, using the _authorisedUserEmailVerificationCodeSend_ operation, is submitted here to verify the authorised user&#x27;s email.  This is needed as part of the verification process for basic due diligence.  _Note that on the Sandbox Environment, the &#x60;verificationCode&#x60; is always set to \\\&quot;123456\\\&quot;._ 
    * @param body  (required)
   */
  @RequestLine("POST /users/verification/email/verify")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void authorisedUserEmailVerify(EmailVerifyBody body);

  /**
   * Activate a user
   * Activate the user identified by the &#x60;user_id&#x60; path parameter.  By default, any new users created will be automatically activated. This operation needs to be used only if the user was previously de-activated using the _userDeactivate_ operation, or if the user was de-activated automatically after multiple incorrect login attempts. 
    * @param user_id The user id for which this password is created. (required)
   */
  @RequestLine("POST /users/{user_id}/activate")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void userActivate(@Param("user_id") Object user_id);

  /**
   * Create a user
   * Creates a user linked to the logged-in corporate or consumer identity.  Once on-boarded, users have access to all instruments (cards and accounts) of the identity.  Application-specific permissions to limit what each user can view and do need to be implemented in your application. 
    * @param body  (optional)
   * @return User
   */
  @RequestLine("POST /users")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  User userCreate(UserCreateRequest body);

  /**
   * Deactivate a user
   * De-activate the user identified by the &#x60;user_id&#x60; path parameter.  Deactivated users cannot log in or execute any operations with their credentials.  This operations is not final and a user can be re-activated using the userActivate operation. Note that another active user would need to log in so as to re-activate the de-activated user. 
    * @param user_id The user id for which this password is created. (required)
   */
  @RequestLine("POST /users/{user_id}/deactivate")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void userDeactivate(@Param("user_id") Object user_id);

  /**
   * Get a user
   * Retrieves the user identified by the &#x60;user_id&#x60; path parameter.
    * @param user_id The user id for which this password is created. (required)
   * @return User
   */
  @RequestLine("GET /users/{user_id}")
  @Headers({
    "Accept: application/json",  })
  User userGetById(@Param("user_id") Object user_id);

  /**
   * Consume a user invite
   * Consumes an invitation perviously sent to the user via _userInviteSend_. This is needed so that the invited user sets up the password.  _Note that on the Sandbox Environment, the &#x60;inviteCode&#x60; is always set to \\\&quot;123456\\\&quot;._ 
    * @param user_id The unique identifier for the user. (required)
    * @param body  (optional)
   * @return TokenResponse
   */
  @RequestLine("POST /users/{user_id}/invite/consume")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  TokenResponse userInviteConsume(@Param("user_id") Object user_id, UserInviteConsumeRequest body);

  /**
   * Send a user invite
   * Once a user is created using the _userCreate_ operation, the user needs to setup his/her password.  An invitation needs to be sent to the user in order to be able to set up the password for the first time. The invitation email, which remains valid for 1 month, will contain a URL having all information required to setup the password via the _userInviteConsume_. 
    * @param user_id The unique identifier for the user. (required)
   */
  @RequestLine("POST /users/{user_id}/invite")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void userInviteSend(@Param("user_id") Object user_id);

  /**
   * Validate a user invite
   * Check if a user&#x27;s invite is still valid. This operation is useful to avoid having the user fill in a form only to be held by a validation issue (eg. expired invite).
    * @param user_id The unique identifier for the user. (required)
    * @param body  (optional)
   */
  @RequestLine("POST /users/{user_id}/invite/validate")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void userInviteValidate(@Param("user_id") Object user_id, UserInviteValidateRequest body);

  /**
   * Start KYC for the user
   * Perform the kyc for a corporate user. 
   * @return InlineResponse20019
   */
  @RequestLine("POST /users/kyc")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse20019 userKyc();

  /**
   * Update a user
   * Update the details of a user identified by the &#x60;user_id&#x60; in the the path parameter.  Only the fields that are specified in the request body will be updated. All other fields will remain unchanged. 
    * @param user_id The user id for which this password is created. (required)
    * @param body  (optional)
   * @return User
   */
  @RequestLine("PATCH /users/{user_id}")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  User userUpdate(@Param("user_id") Object user_id, UserPatchRequest body);

  /**
   * Get all users
   * Fetches all authorised users associated with the corporate or consumer identity the logged-in user belongs to.
    * @param offset The offset value for paging, indicating the initial item number to be returned from the data set satisfying the given criteria. Leave out to fetch the first page of results. (optional)
    * @param limit The limit of the results for paging, starting at the offset. Limit is always capped at 100. (optional)
    * @param active Filter for active or deactivated users. Leave out to fetch all users. (optional)
    * @param email Filter by the email address of the user. (optional)
   * @return InlineResponse20015
   */
  @RequestLine("GET /users?offset={offset}&limit={limit}&active={active}&email={email}")
  @Headers({
    "Accept: application/json",  })
  InlineResponse20015 usersGet(@Param("offset") Integer offset, @Param("limit") Integer limit, @Param("active") Boolean active, @Param("email") Object email);


    /**
     * Get all users
     * Fetches all authorised users associated with the corporate or consumer identity the logged-in user belongs to.
     * Note, this is equivalent to the other <code>usersGet</code> method,
     * but with the query parameters collected into a single Map parameter. This
     * is convenient for services with optional query parameters, especially when
     * used with the {@link UsersGetQueryParams} class that allows for
     * building up this map in a fluent style.
     * @param queryParams Map of query parameters as name-value pairs
     *   <p>The following elements may be specified in the query map:</p>
     *   <ul>
     *   <li>offset - The offset value for paging, indicating the initial item number to be returned from the data set satisfying the given criteria. Leave out to fetch the first page of results. (optional)</li>
     *   <li>limit - The limit of the results for paging, starting at the offset. Limit is always capped at 100. (optional)</li>
     *   <li>active - Filter for active or deactivated users. Leave out to fetch all users. (optional)</li>
     *   <li>email - Filter by the email address of the user. (optional)</li>
     *   </ul>
     * @return InlineResponse20015
     */
    @RequestLine("GET /users?offset={offset}&limit={limit}&active={active}&email={email}")
    @Headers({
    "Accept: application/json",    })
    InlineResponse20015 usersGet
    (@QueryMap(encoded=true)
    MultiValueMap<String, String> queryParams);

}
