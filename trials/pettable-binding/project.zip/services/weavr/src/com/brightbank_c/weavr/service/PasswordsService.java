package com.brightbank_c.weavr.service;


import com.brightbank_c.weavr.model.*;
import com.brightbank_c.weavr.model.EmailRequest;
import com.brightbank_c.weavr.model.Error;
import com.brightbank_c.weavr.model.InlineResponse2006;
import com.brightbank_c.weavr.model.InlineResponse400;
import com.brightbank_c.weavr.model.InlineResponse40910;
import com.brightbank_c.weavr.model.InlineResponse40930;
import com.brightbank_c.weavr.model.InlineResponse40942;
import com.brightbank_c.weavr.model.InlineResponse40943;
import com.brightbank_c.weavr.model.InlineResponse40959;
import com.brightbank_c.weavr.model.LostPasswordResumeRequest;
import com.brightbank_c.weavr.model.PasswordCreateRequest;
import com.brightbank_c.weavr.model.PasswordUpdateRequest;
import com.brightbank_c.weavr.model.PasswordValidateRequest;
import com.brightbank_c.weavr.model.TokenResponse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Object;
import org.springframework.util.MultiValueMap;
import feign.*;

public interface PasswordsService {

  /**
   * Initiate lost password process
   * Initiate the lost password process.  If the email address provided is associated with an active user, an email will be sent, containing a URL that redirects the user to change their password. The URL contains request parameters for all of the parameters required to change the password for the user via the &#x60;/passwords/lost_password/resume&#x60; POST endpoint. 
    * @param body  (optional)
   */
  @RequestLine("POST /passwords/lost_password/start")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void lostPasswordInitiate(EmailRequest body);

  /**
   * Resume lost password process
   * This is the second and final step in updating the password of a user who forgot their password.
    * @param body  (optional)
   * @return TokenResponse
   */
  @RequestLine("POST /passwords/lost_password/resume")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  TokenResponse lostPasswordResume(LostPasswordResumeRequest body);

  /**
   * Create a password
   * Create a new password for the user identified by the &#x60;user_id&#x60; path parameter.
    * @param user_id The user id for which this password is created. (required)
    * @param body  (optional)
   * @return InlineResponse2006
   */
  @RequestLine("POST /passwords/{user_id}/create")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse2006 passwordCreate(@Param("user_id") Object user_id, PasswordCreateRequest body);

  /**
   * Update a password
   * Update the password for the logged-in user.
    * @param body  (optional)
   * @return InlineResponse2006
   */
  @RequestLine("POST /passwords/update")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  InlineResponse2006 passwordUpdate(PasswordUpdateRequest body);

  /**
   * Validate a password
   * Check that a password adheres to all complexity checks.
    * @param body  (optional)
   */
  @RequestLine("POST /passwords/validate")
  @Headers({
    "Content-Type: application/json",
    "Accept: application/json",  })
  void passwordValidate(PasswordValidateRequest body);

}
