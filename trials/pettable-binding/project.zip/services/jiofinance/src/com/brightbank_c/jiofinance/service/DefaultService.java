package com.brightbank_c.jiofinance.service;


import com.brightbank_c.jiofinance.model.*;
import java.time.LocalDate;
import com.brightbank_c.jiofinance.model.StockData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.Object;
import org.springframework.util.MultiValueMap;
import feign.*;

public interface DefaultService {

  /**
   * Get historical stock data for JIOFIN
   * 
    * @param from Start date (YYYY-MM-DD) (required)
    * @param to End date (YYYY-MM-DD) (required)
   * @return List&lt;StockData&gt;
   */
  @RequestLine("GET /stocks/jiofin/history?from={from}&to={to}")
  @Headers({
    "Accept: */*",  })
  List<StockData> getStocksJiofinHistory(@Param("from") LocalDate from, @Param("to") LocalDate to);


    /**
     * Get historical stock data for JIOFIN
     * 
     * Note, this is equivalent to the other <code>getStocksJiofinHistory</code> method,
     * but with the query parameters collected into a single Map parameter. This
     * is convenient for services with optional query parameters, especially when
     * used with the {@link GetStocksJiofinHistoryQueryParams} class that allows for
     * building up this map in a fluent style.
     * @param queryParams Map of query parameters as name-value pairs
     *   <p>The following elements may be specified in the query map:</p>
     *   <ul>
     *   <li>from - Start date (YYYY-MM-DD) (required)</li>
     *   <li>to - End date (YYYY-MM-DD) (required)</li>
     *   </ul>
     * @return List&lt;StockData&gt;
     */
    @RequestLine("GET /stocks/jiofin/history?from={from}&to={to}")
    @Headers({
    "Accept: */*",    })
    List<StockData> getStocksJiofinHistory
    (@QueryMap(encoded=true)
    MultiValueMap<String, String> queryParams);

  /**
   * Get live stock data for JIOFIN
   * Returns current price, change, volume, and other live data
   * @return StockData
   */
  @RequestLine("GET /stocks/jiofin/live")
  @Headers({
    "Accept: */*",  })
  StockData getStocksJiofinLive();

}
