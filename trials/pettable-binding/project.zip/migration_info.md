# 🚀 Migration Report

## 📌 Version: 11.12

- Moved 'overrides' folder to 'design-tokens'
- Moved 'app.override.css' file to 'design-tokens'
- Deleted 'themes' folder
- Updated index.html to refer 'design-tokens' folder


- Added new default file `package-override.json` to /build-src/
- Added new default file `eslintrc-override.js` to /build-src/


- Removed aria label attribute from `12` page markup files


- Updated ui-build.js file
- Updated build.xml file


